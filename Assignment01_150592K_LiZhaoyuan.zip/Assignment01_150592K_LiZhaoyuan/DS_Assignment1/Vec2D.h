#ifndef VEC2D_H_
#define VEC2D_H_

struct Vec2D
{
public:
	Vec2D();
	Vec2D(double x, double y ) ;
	//virtual ~Vec2D();

	
	double x;
	double y;

	
};

#endif