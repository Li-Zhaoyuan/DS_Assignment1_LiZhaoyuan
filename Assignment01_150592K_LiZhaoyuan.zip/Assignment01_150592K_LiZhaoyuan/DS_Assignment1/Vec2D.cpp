#include "Vec2D.h"

Vec2D::Vec2D()
{
	x = 0;
	y = 0;
}

Vec2D::Vec2D(double x, double y)
:x(x), y(y)
{

}

